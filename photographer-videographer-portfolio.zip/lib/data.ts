// Sample data for the portfolio - Replace with your actual content
// Images are placeholders - replace with your own URLs

export interface Photo {
  id: string
  title: string
  creator: "photographer" | "videographer"
  category: "fashion" | "cars" | "lifestyle" | "events"
  location: string
  imageUrl: string
  type: "photo" | "video"
  gallery: string[]
}

export interface Creator {
  id: string
  name: string
  role: "photographer" | "videographer"
  bio: string
  imageUrl: string
  socials: {
    instagram?: string
    telegram?: string
    twitter?: string
    email?: string
  }
}

export const portfolioItems: Photo[] = [
  {
    id: "1",
    title: "Fashion Session 1",
    creator: "photographer",
    category: "fashion",
    location: "Studio",
    imageUrl: "/fashion-photography.png",
    type: "photo",
    gallery: [
      "/fashion-model-elegant-pose-studio-lighting.jpg",
      "/fashion-portrait-dramatic-shadows.jpg",
      "/fashion-photoshoot-elegant-dress.jpg",
      "/high-fashion-editorial.png",
      "/fashion-model-close-up-portrait.jpg",
    ],
  },
  {
    id: "2",
    title: "Car Photoshoot",
    creator: "photographer",
    category: "cars",
    location: "Mini Castle",
    imageUrl: "/sleek-red-sports-car.png",
    type: "photo",
    gallery: [
      "/red-sports-car-luxury-photography.jpg",
      "/car-detail-shot-wheel-and-body.jpg",
      "/sports-car-interior-leather-seats.jpg",
      "/luxury-car-front-view-dramatic-lighting.jpg",
      "/car-photoshoot-sunset-background.jpg",
    ],
  },
  {
    id: "3",
    title: "Lifestyle Video",
    creator: "videographer",
    category: "lifestyle",
    location: "Urban",
    imageUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    type: "video",
    gallery: [
      "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
      "/lifestyle-video-frame-urban-setting.jpg",
      "/cinematic-street-photography-people.jpg",
      "/urban-lifestyle-candid-moment.jpg",
      "/city-life-documentary-style.jpg",
    ],
  },
  {
    id: "4",
    title: "Event Coverage",
    creator: "videographer",
    category: "events",
    location: "Studio",
    imageUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    type: "video",
    gallery: [
      "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
      "/corporate-event-professional-videography.jpg",
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
    ],
  },
  {
    id: "5",
    title: "Fashion Session 2",
    creator: "photographer",
    category: "fashion",
    location: "Outdoor",
    imageUrl: "/portrait-fashion.jpg",
    type: "photo",
    gallery: [
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
    ],
  },
  {
    id: "6",
    title: "Wedding Highlights",
    creator: "videographer",
    category: "events",
    location: "Mini Castle",
    imageUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    type: "video",
    gallery: [
      "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
    ],
  },
  {
    id: "7",
    title: "Vintage Car Collection",
    creator: "photographer",
    category: "cars",
    location: "Studio",
    imageUrl: "/placeholder.svg?height=600&width=800",
    type: "photo",
    gallery: [
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
    ],
  },
  {
    id: "8",
    title: "Street Style Documentary",
    creator: "videographer",
    category: "lifestyle",
    location: "Urban",
    imageUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
    type: "video",
    gallery: [
      "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
      "/placeholder.svg?height=800&width=1200",
    ],
  },
]

// Creator information
export const creators: Creator[] = [
  {
    id: "1",
    name: "Alex Chen",
    role: "photographer",
    bio: "Passionate about capturing authentic moments and timeless aesthetics. Specializing in fashion and lifestyle photography.",
    imageUrl: "/professional-photographer.png",
    socials: {
      instagram: "https://instagram.com",
      telegram: "https://telegram.org",
      twitter: "https://twitter.com",
      email: "alex@example.com",
    },
  },
  {
    id: "2",
    name: "Maria Santos",
    role: "videographer",
    bio: "Creative videographer with a passion for storytelling. Expert in event coverage and cinematic lifestyle content.",
    imageUrl: "/professional-videographer.png",
    socials: {
      instagram: "https://instagram.com",
      telegram: "https://telegram.org",
      email: "maria@example.com",
    },
  },
]

// Statistics data
export const statistics = [
  { label: "Photoshoots", value: "150+" },
  { label: "Projects", value: "500+" },
  { label: "Videos", value: "20K+" },
  { label: "Clients", value: "50+" },
]

// Categories with random images from the portfolio
export const categories = [
  {
    id: "1",
    name: "Fashion",
    icon: "👗",
    description: "High-fashion and lifestyle portraits",
  },
  {
    id: "2",
    name: "Cars",
    icon: "🚗",
    description: "Automotive photography and cinematography",
  },
  {
    id: "3",
    name: "Lifestyle",
    icon: "✨",
    description: "Candid moments and everyday beauty",
  },
  {
    id: "4",
    name: "Events",
    icon: "🎬",
    description: "Corporate and special event coverage",
  },
]
