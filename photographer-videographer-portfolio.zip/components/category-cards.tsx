"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { motion } from "framer-motion"
import { theme } from "@/lib/theme"
import { categories, portfolioItems } from "@/lib/data"
import { useLanguageContext } from "@/contexts/LanguageContext"
import { translations } from "@/lib/i18n"
import Image from "next/image"
import Link from "next/link"

export function CategoryCards() {
  const [scrollX, setScrollX] = useState(0)
  const [isPaused, setIsPaused] = useState(false)
  const [isHovering, setIsHovering] = useState(false)
  const [preventScroll, setPreventScroll] = useState(false)
  const scrollContainerRef = useRef<HTMLDivElement>(null)
  const animationFrameRef = useRef<number>()
  const hoverTimerRef = useRef<NodeJS.Timeout>()
  const { language } = useLanguageContext()
  const t = translations[language]

  // Get a random image from portfolio for each category
  const getCategoryImage = (categoryName: string) => {
    const categoryItems = portfolioItems.filter((item) => item.category === categoryName.toLowerCase())
    return categoryItems.length > 0 ? categoryItems[0].imageUrl : "/placeholder.svg"
  }

  useEffect(() => {
    const speed = 0.5 // pixels per frame (adjust for faster/slower scrolling)

    const animate = () => {
      if (!isPaused && scrollContainerRef.current) {
        setScrollX((prev) => {
          const container = scrollContainerRef.current
          if (!container) return prev

          // Calculate the width of one full set of cards
          const cardWidth = 400 // approximate width including gap
          const totalWidth = categories.length * cardWidth

          // Reset to 0 when reaching the end for seamless loop
          if (prev >= totalWidth) {
            return 0
          }

          return prev + speed
        })
      }
      animationFrameRef.current = requestAnimationFrame(animate)
    }

    animationFrameRef.current = requestAnimationFrame(animate)

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
    }
  }, [isPaused, categories.length])

  const handleMouseEnter = () => {
    setIsHovering(true)
    setIsPaused(true)

    hoverTimerRef.current = setTimeout(() => {
      setPreventScroll(true)
    }, 500) // 500ms delay before preventing page scroll
  }

  const handleMouseLeave = () => {
    setIsHovering(false)
    setIsPaused(false)
    setPreventScroll(false)

    if (hoverTimerRef.current) {
      clearTimeout(hoverTimerRef.current)
    }
  }

  const handleWheel = (e: React.WheelEvent) => {
    if (!scrollContainerRef.current) return

    if (preventScroll) {
      e.preventDefault()
      e.stopPropagation()
    }

    setScrollX((prev) => {
      const newScroll = prev + e.deltaY * 0.5
      const cardWidth = 400
      const totalWidth = categories.length * cardWidth

      if (newScroll < 0) return 0
      if (newScroll >= totalWidth) return totalWidth - 1

      return newScroll
    })
  }

  const duplicatedCategories = [...categories, ...categories, ...categories]

  return (
    <section style={{ backgroundColor: theme.colors.neutral.bgSecondary }} className="py-20 px-6 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-2" style={{ color: theme.colors.neutral.text }}>
            {t.categories.title}
          </h2>
          <p className="text-sm uppercase tracking-widest" style={{ color: theme.colors.accent.orange }}>
            {t.categories.explore}
          </p>
        </motion.div>

        <div
          ref={scrollContainerRef}
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
          onWheel={handleWheel}
          className="relative overflow-hidden"
        >
          <motion.div
            className="flex gap-6"
            style={{
              transform: `translateX(-${scrollX}px)`,
              transition: "none",
            }}
          >
            {duplicatedCategories.map((card, index) => {
              const categoryImage = getCategoryImage(card.name)

              return (
                <Link key={`${card.id}-${index}`} href={`/works?category=${card.name.toLowerCase()}`}>
                  <motion.div
                    whileHover={{ y: -10, scale: 1.02 }}
                    className="flex-shrink-0 w-[380px] cursor-pointer overflow-hidden rounded-lg h-80"
                    style={{
                      backgroundColor: theme.colors.neutral.bg,
                      border: `1px solid ${theme.colors.neutral.border}`,
                    }}
                  >
                    {/* Background Image */}
                    <div className="relative h-full w-full overflow-hidden">
                      <Image
                        src={categoryImage || "/placeholder.svg"}
                        alt={card.name}
                        fill
                        className="object-cover group-hover:scale-110 transition-transform duration-500"
                      />

                      {/* Dark Overlay */}
                      <div className="absolute inset-0" style={{ backgroundColor: "rgba(10, 14, 39, 0.6)" }} />

                      {/* Content */}
                      <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ duration: 0.5, delay: 0.2 }}
                          className="text-5xl mb-4"
                        >
                          {card.icon}
                        </motion.div>
                        <h3 className="text-2xl font-bold mb-2" style={{ color: theme.colors.neutral.text }}>
                          {card.name}
                        </h3>
                        <p className="text-sm" style={{ color: theme.colors.neutral.textSecondary }}>
                          {card.description}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                </Link>
              )
            })}
          </motion.div>

          {/* Gradient Overlays for smooth edges */}
          <div
            className="absolute left-0 top-0 bottom-0 w-20 pointer-events-none"
            style={{
              background: `linear-gradient(to right, ${theme.colors.neutral.bgSecondary}, transparent)`,
            }}
          />
          <div
            className="absolute right-0 top-0 bottom-0 w-20 pointer-events-none"
            style={{
              background: `linear-gradient(to left, ${theme.colors.neutral.bgSecondary}, transparent)`,
            }}
          />
        </div>

        {/* Hint Text */}
        <p
          className="text-xs text-center mt-6 uppercase tracking-widest"
          style={{ color: theme.colors.neutral.textSecondary }}
        >
          {t.categories.scrollHint || "Hover to pause • Scroll with mouse wheel"}
        </p>
      </div>
    </section>
  )
}
